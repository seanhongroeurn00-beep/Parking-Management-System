# System Parking — Windows Server 2019 (3 Servers)

```
Internet ──HTTPS 443──▶ [Frontend 192.168.111.12]  IIS + HTTPS + ARR proxy
                              │  /api/*  → http://192.168.111.78:5000
                              ▼
                        [Backend 192.168.111.78]   Node.js + pm2  (គ្មាន Internet)
                              │  MariaDB 3306
                              ▼
                        [DB 192.168.111.107]       MariaDB         (គ្មាន Internet)
```

| Server | IP | ថត​ត្រូវ copy | Internet | Port |
|---|---|---|---|---|
| Frontend | 192.168.111.12 | `frontend/` | មាន | 80, 443 (ពីគ្រប់ទី) |
| Backend  | 192.168.111.78 | `backend/` (មាន `node_modules` រួច) | គ្មាន | 5000 ← តែ .12 |
| Database | 192.168.111.107 | `database/` | គ្មាន | 3306 ← តែ .78 |

## លំដាប់តំឡើង (DB → Backend → Frontend)

**1. Database (.107)** — តំឡើង MariaDB 10.5+ កំណត់ root password រួចរត់ PowerShell ជា Administrator៖
```powershell
.\database\scripts\setup-database.ps1
```
ធ្វើ: bind-address=.107, Firewall 3306 ← .78, import `parking_db.sql`, បង្កើត user `parking_app@192.168.111.78`។

**2. Backend (.78)** — តំឡើង Node.js LTS + pm2 (`npm i -g pm2`) រួចរត់៖
```powershell
.\backend\scripts\setup-backend.ps1
```
ធ្វើ: Firewall 5000 ← .12, `pm2 start ecosystem.config.js`, `pm2 save`, Scheduled Task `pm2 resurrect` ពេល boot (រត់ជានិច្ច)។ ការកំណត់ DB នៅក្នុង `backend\.env`។

**3. Frontend (.12)** — រត់៖
```powershell
.\frontend\scripts\setup-frontend.ps1                       # បង្កើត self-signed cert ដោយស្វ័យប្រវត្តិ
.\frontend\scripts\setup-frontend.ps1 -Thumbprint <THUMB>   # ឬប្រើ cert ដែលបានបង្កើតក្នុង IIS រួច
```
ធ្វើ: តំឡើង IIS + URL Rewrite + ARR (enable proxy), copy website, bind HTTPS 443, Firewall 80/443។

## តេស្ត
| ពី | ពាក្យបញ្ជា | លទ្ធផលត្រូវមាន |
|---|---|---|
| .78 | `Test-NetConnection 192.168.111.107 -Port 3306` | TcpTestSucceeded True |
| .78 | `curl http://127.0.0.1:5000/api/health` | `{"status":"ok","db":"connected"}` |
| .12 | `curl http://192.168.111.78:5000/api/health` | `{"status":"ok","db":"connected"}` |
| Browser | `https://<domain-ឬ-IP-.12>/` | ទំព័រ Login |

Login លំនាំដើម: `admin` / `Admin123` (security1 / Admin123) — **ប្តូរភ្លាមៗ**។

## កំណត់ចំណាំ
- Browser ហៅ `/api/...` តាម IIS (same-origin) ដូច្នេះ Backend មិនត្រូវការ Internet ហើយ CORS បិទ (បើក តាម `CORS_ORIGIN` ក្នុង `.env`)។
- ពេលកែ code ក្នុង Backend: `pm2 restart parking-api`។ Logs នៅ `C:\parking-logs\`។
- ប្តូរ password `parking_app` (លំនាំដើម `Admin@123`) ត្រូវកែទាំង `database\parking_db.sql` (ផ្នែក ៩) និង `backend\.env`។
- `.env` និង `node_modules` ត្រូវបាន ignore ក្នុង git (`.gitignore`) តែបានដាក់ក្នុង zip នេះសម្រាប់ Backend ដែលគ្មាន Internet។
