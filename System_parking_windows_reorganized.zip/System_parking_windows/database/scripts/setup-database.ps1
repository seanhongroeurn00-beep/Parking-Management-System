﻿# ===== Run on DATABASE server 192.168.111.107 as Administrator =====
# Prerequisite: MariaDB 10.5+ installed (service name "MariaDB") and root password set.
# This server has NO internet. Copy the whole "database" folder to it first.
$ErrorActionPreference = "Stop"
$BackendIP = "192.168.111.78"
$DbIP      = "192.168.111.107"
$sqlFile   = (Join-Path (Split-Path $PSScriptRoot) "parking_db.sql") -replace '\\','/'

# 1) bind-address in my.ini (listen on the LAN IP, not only localhost)
$ini = Get-ChildItem "C:\Program Files\MariaDB*" -Recurse -Filter my.ini -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $ini) { throw "my.ini not found under C:\Program Files\MariaDB*" }
$txt = Get-Content $ini.FullName -Raw
if ($txt -match '(?m)^\s*bind-address\s*=.*$') {
  $txt = $txt -replace '(?m)^\s*bind-address\s*=.*$', "bind-address=$DbIP"
} else {
  $txt = $txt -replace '\[mysqld\]', "[mysqld]`r`nbind-address=$DbIP"
}
Set-Content $ini.FullName $txt -Encoding ASCII
Restart-Service MariaDB

# 2) Windows Firewall: only the Backend may reach MariaDB
New-NetFirewallRule -DisplayName "MariaDB-3306-from-Backend" -Direction Inbound -Protocol TCP -LocalPort 3306 -RemoteAddress $BackendIP -Action Allow -ErrorAction SilentlyContinue | Out-Null

# 3) Import database (WARNING: drops and recreates the parking tables)
$mysql = Get-ChildItem "C:\Program Files\MariaDB*\bin\mysql.exe","C:\Program Files\MariaDB*\bin\mariadb.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $mysql) { throw "mysql.exe / mariadb.exe not found" }
& $mysql.FullName -u root -p --default-character-set=utf8mb4 -e "source $sqlFile"
Write-Host "DONE: database ready on ${DbIP}:3306 (user parking_app allowed from $BackendIP)" -ForegroundColor Green
