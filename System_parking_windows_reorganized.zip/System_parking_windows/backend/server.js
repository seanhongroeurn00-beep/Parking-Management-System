const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const db = require('./config/db');
const parkingRoutes = require('./routes/parkingRoutes');

const app = express();

// Frontend (IIS 192.168.111.12) proxy /api -> Backend ដូច្នេះ Browser ហៅ same-origin មិនត្រូវការ CORS ទេ។
// បើចង់បើក CORS ពិតប្រាកដ សូមដាក់ CORS_ORIGIN=https://your-domain ក្នុង .env
if (process.env.CORS_ORIGIN) {
    app.use(cors({
        origin: process.env.CORS_ORIGIN.split(',').map(s => s.trim()),
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        allowedHeaders: ['Content-Type', 'Authorization']
    }));
}

app.use(express.json());

// Health check (សម្រាប់តេស្ត: http://192.168.111.78:5000/api/health)
app.get('/api/health', async (req, res) => {
    try {
        await db.query('SELECT 1');
        res.json({ status: 'ok', db: 'connected' });
    } catch (error) {
        res.status(500).json({ status: 'error', db: 'unreachable', error: error.message });
    }
});

app.use('/api/parking', parkingRoutes);

const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';
app.listen(PORT, HOST, () => {
    console.log(`Parking API running on ${HOST}:${PORT}`);
});
