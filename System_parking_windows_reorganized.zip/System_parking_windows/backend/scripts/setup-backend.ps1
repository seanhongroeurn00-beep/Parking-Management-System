﻿# ===== Run on BACKEND server 192.168.111.78 as Administrator =====
# Prerequisites: Node.js LTS and pm2 already installed (npm i -g pm2).
# This server has NO internet, so node_modules is shipped inside the "backend" folder (no npm install needed).
$ErrorActionPreference = "Stop"
$FrontendIP = "192.168.111.12"
$DbIP       = "192.168.111.107"
$app        = Split-Path $PSScriptRoot
$pm2Home    = "C:\ProgramData\pm2"
$logDir     = "C:\parking-logs"

$pm2 = (Get-Command pm2.cmd -ErrorAction SilentlyContinue).Source
if (-not $pm2) { throw "pm2 not found. Install it (npm i -g pm2) or copy it from a machine with internet." }
if (-not (Test-Path (Join-Path $app "node_modules"))) { throw "node_modules missing in $app" }
if (-not (Test-Path (Join-Path $app ".env")))         { throw ".env missing in $app (copy .env.example to .env)" }

# 1) Firewall: API port 5000 only from the Frontend
New-NetFirewallRule -DisplayName "Parking-API-5000-from-Frontend" -Direction Inbound -Protocol TCP -LocalPort 5000 -RemoteAddress $FrontendIP -Action Allow -ErrorAction SilentlyContinue | Out-Null

# 2) Stop any old pm2 daemon (default home), then use one fixed PM2_HOME for all users incl. SYSTEM at boot
& $pm2 kill 2>$null | Out-Null
New-Item -ItemType Directory -Force $pm2Home, $logDir | Out-Null
[Environment]::SetEnvironmentVariable("PM2_HOME", $pm2Home, "Machine")
$env:PM2_HOME = $pm2Home

# 3) Start the API with pm2 and save the process list
Set-Location $app
& $pm2 start ecosystem.config.js
& $pm2 save --force

# 4) Auto-start at boot (pm2 has no native Windows startup): scheduled task as SYSTEM -> pm2 resurrect
$action    = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"$pm2`" resurrect"
$trigger   = New-ScheduledTaskTrigger -AtStartup
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
Register-ScheduledTask -TaskName "Parking-API-pm2-resurrect" -Action $action -Trigger $trigger -Principal $principal -Force | Out-Null

# 5) Checks
Start-Sleep 3
Test-NetConnection $DbIP -Port 3306 | Select-Object ComputerName, RemotePort, TcpTestSucceeded
try { (Invoke-WebRequest "http://127.0.0.1:5000/api/health" -UseBasicParsing).Content } catch { Write-Warning "Health check failed: $($_.Exception.Message)" }
Write-Host "DONE: backend running under pm2 (name: parking-api)" -ForegroundColor Green
