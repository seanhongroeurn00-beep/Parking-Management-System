// pm2 config សម្រាប់ Backend 192.168.111.78
// ប្រើ: pm2 start ecosystem.config.js  →  pm2 save
module.exports = {
  apps: [{
    name: 'parking-api',
    script: 'server.js',
    cwd: __dirname,
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    max_restarts: 20,
    restart_delay: 3000,
    max_memory_restart: '300M',
    time: true,
    merge_logs: true,
    out_file: 'C:/parking-logs/api-out.log',
    error_file: 'C:/parking-logs/api-error.log',
    env: { NODE_ENV: 'production' }
  }]
};
