﻿# ===== Run on FRONTEND server 192.168.111.12 as Administrator =====
# This server HAS internet (needed to download URL Rewrite + ARR).
# Optional: -Thumbprint <cert thumbprint>  use the HTTPS certificate you already created in IIS
#           -DnsName <name>                create a self-signed certificate for this name (default parking.local)
param(
  [string]$Thumbprint = "",
  [string]$DnsName    = "parking.local",
  [string]$SiteName   = "Default Web Site",
  [string]$SitePath   = "C:\inetpub\wwwroot"
)
$ErrorActionPreference = "Stop"
$BackendIP = "192.168.111.78"
$src = Split-Path $PSScriptRoot      # the "frontend" folder
$tmp = "C:\temp"; New-Item -ItemType Directory -Force $tmp | Out-Null
$appcmd = "$env:windir\system32\inetsrv\appcmd.exe"

# 1) IIS
Install-WindowsFeature Web-Server, Web-Static-Content, Web-Default-Doc, Web-Http-Errors, Web-Filtering -IncludeManagementTools | Out-Null

# 2) URL Rewrite + ARR (skip if already installed)
$urlRewrite = "https://download.microsoft.com/download/1/2/8/128E2E22-C1B9-44A4-BE2A-5859ED1D4592/rewrite_amd64_en-US.msi"
$arr        = "https://download.microsoft.com/download/E/9/8/E9849D6A-020E-47E4-9FD0-A023E99B54EB/requestRouter_amd64.msi"
if (-not (Test-Path "$env:windir\system32\inetsrv\rewrite.dll")) {
  $f = Join-Path $tmp "rewrite_amd64_en-US.msi"; Invoke-WebRequest $urlRewrite -OutFile $f
  Start-Process msiexec.exe -ArgumentList "/i `"$f`" /qn" -Wait
}
if (-not (Test-Path "$env:ProgramFiles\IIS\Application Request Routing")) {
  $f = Join-Path $tmp "requestRouter_amd64.msi"; Invoke-WebRequest $arr -OutFile $f
  Start-Process msiexec.exe -ArgumentList "/i `"$f`" /qn" -Wait
}
& $appcmd set config -section:system.webServer/proxy /enabled:"True" /commit:apphost | Out-Null

# 3) Deploy the website (html + web.config)
New-Item -ItemType Directory -Force $SitePath | Out-Null
Get-ChildItem $SitePath -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem $src -Exclude scripts | Copy-Item -Destination $SitePath -Recurse -Force

# 4) HTTPS binding on 443
Import-Module WebAdministration
if ($Thumbprint) {
  $cert = Get-Item "Cert:\LocalMachine\My\$Thumbprint"
} else {
  $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Subject -eq "CN=$DnsName" -and $_.NotAfter -gt (Get-Date) } | Select-Object -First 1
  if (-not $cert) { $cert = New-SelfSignedCertificate -DnsName $DnsName -CertStoreLocation Cert:\LocalMachine\My -NotAfter (Get-Date).AddYears(2) }
}
if (-not (Get-WebBinding -Name $SiteName -Protocol https)) { New-WebBinding -Name $SiteName -Protocol https -Port 443 }
$b = Get-WebBinding -Name $SiteName -Protocol https
$b.AddSslCertificate($cert.Thumbprint, "My") 2>$null

# 5) Windows Firewall
New-NetFirewallRule -DisplayName "HTTP-80"   -Direction Inbound -Protocol TCP -LocalPort 80  -Action Allow -ErrorAction SilentlyContinue | Out-Null
New-NetFirewallRule -DisplayName "HTTPS-443" -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow -ErrorAction SilentlyContinue | Out-Null
iisreset | Out-Null

# 6) Checks
Test-NetConnection $BackendIP -Port 5000 | Select-Object ComputerName, RemotePort, TcpTestSucceeded
try { (Invoke-WebRequest "http://${BackendIP}:5000/api/health" -UseBasicParsing).Content } catch { Write-Warning "Backend health failed: $($_.Exception.Message)" }
Write-Host "DONE: frontend ready -> https://$DnsName/  (certificate thumbprint $($cert.Thumbprint))" -ForegroundColor Green
